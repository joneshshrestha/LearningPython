from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='The Head First Python Search Tools',
    author='Jonesh',
    author_email='joneshshrestha69@gmail.com',
    url='www.joneshshrestha.com',
    py_modules=['vsearch']
    )
